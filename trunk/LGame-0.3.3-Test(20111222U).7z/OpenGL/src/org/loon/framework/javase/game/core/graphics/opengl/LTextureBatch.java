package org.loon.framework.javase.game.core.graphics.opengl;

import java.nio.FloatBuffer;

import org.loon.framework.javase.game.core.LRelease;
import org.loon.framework.javase.game.utils.BufferUtils;

/**
 * Copyright 2008 - 2011
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * @project loonframework
 * @author chenpeng
 * @email：ceponline@yahoo.com.cn
 * @version 0.1
 */
// 此类专为批量渲染单一纹理而设置（比如处理海量精灵块，地图块等），允许提交缓存中数据到渲染器
public final class LTextureBatch implements LRelease {

	private GLCache lastCache;

	public static class GLCache implements LRelease {

		FloatBuffer vertexBuffer;

		FloatBuffer coordsBuffer;

		FloatBuffer colorBuffer;

		public float x, y;

		int count;

		boolean isColor;

		public GLCache(LTextureBatch batch) {
			this(batch, true);
		}

		public GLCache(LTextureBatch batch, boolean reset) {

			if (reset) {
				batch.insertVertices();
			}

			this.count = batch.count;
			this.isColor = batch.isColor;

			vertexBuffer = BufferUtils.createFloatBuffer(batch.oldVertCount);
			vertexBuffer.put(batch.verts, 0, batch.oldVertCount);
			vertexBuffer.flip();

			if (isColor) {
				colorBuffer = BufferUtils
						.createFloatBuffer(batch.oldColorCount);
				colorBuffer.put(batch.cols, 0, batch.oldColorCount);
				colorBuffer.flip();
			}

			coordsBuffer = BufferUtils.createFloatBuffer(batch.oldCoordCount);
			coordsBuffer.put(batch.coords, 0, batch.oldCoordCount);
			coordsBuffer.flip();

			this.x = batch.moveX;
			this.y = batch.moveY;
		}

		public void flip() {
			if (vertexBuffer != null) {
				vertexBuffer.flip();
			}
			if (coordsBuffer != null) {
				coordsBuffer.flip();
			}
			if (colorBuffer != null) {
				colorBuffer.flip();
			}
		}

		public void limit(int size) {
			if (vertexBuffer != null) {
				vertexBuffer.limit(size);
			}
			if (coordsBuffer != null) {
				coordsBuffer.limit(size);
			}
			if (colorBuffer != null) {
				colorBuffer.limit(size);
			}
		}

		public void position(int newPosition) {
			if (vertexBuffer != null) {
				vertexBuffer.position(newPosition);
			}
			if (coordsBuffer != null) {
				coordsBuffer.position(newPosition);
			}
			if (colorBuffer != null) {
				colorBuffer.position(newPosition);
			}
		}

		public void dispose() {
			vertexBuffer = null;
			coordsBuffer = null;
			colorBuffer = null;
		}

	}

	private static final int DEFAULT_MAX_VERTICES = 3000;

	private float[] color = new float[] { 1f, 1f, 1f, 1f };

	private float[] coord = new float[] { 0f, 0f };

	private int count, maxCount;

	private float[] verts = new float[DEFAULT_MAX_VERTICES * 3];

	private float[] cols = new float[DEFAULT_MAX_VERTICES * 4];

	private float[] coords = new float[DEFAULT_MAX_VERTICES * 2];

	private final LTexture texture;

	private FloatBuffer vertexBuffer;

	private FloatBuffer coordBuffer;

	private FloatBuffer colorBuffer;

	private float moveX, moveY;

	private int batchType, expand;

	private int ver, col, tex;

	private int texWidth, texHeight;

	int oldVertCount, oldColorCount, oldCoordCount;

	boolean useBegin, lockCoord, isColor, isLocked;

	public LTextureBatch(String fileName) {
		this(LTextures.loadTexture(fileName).get(), DEFAULT_MAX_VERTICES);
	}

	public LTextureBatch(LTexture texture) {
		this(texture, DEFAULT_MAX_VERTICES);
	}

	public LTextureBatch(String fileName, int count) {
		this(LTextures.loadTexture(fileName).get(), count);
	}

	public LTextureBatch(LTexture texture, int count) {
		this.texture = texture;
		this.texWidth = texture.width;
		this.texHeight = texture.height;
		this.isLocked = false;
		this.make(count);
	}

	private final void glVertex3f(final int count, float x, float y, float z) {
		this.ver = count * 3;
		this.verts[ver + 0] = x;
		this.verts[ver + 1] = y;
		this.verts[ver + 2] = z;
		this.tex = count * 2;
		this.coords[tex + 0] = coord[0];
		this.coords[tex + 1] = coord[1];
		if (!isColor) {
			return;
		}
		this.col = count * 4;
		this.cols[col + 0] = color[0];
		this.cols[col + 1] = color[1];
		this.cols[col + 2] = color[2];
		this.cols[col + 3] = color[3];
	}

	public void glVertex3f(float x, float y, float z) {
		if (batchType != GL.GL_TRIANGLES) {
			glVertex3f(count, x, y, z);
			count++;
		} else {
			switch (expand) {
			case 0:
				glVertex3f(count, x, y, z);
				glVertex3f(count + 5, x, y, z);
				count++;
				break;
			case 1:
				glVertex3f(count, x, y, z);
				count++;
				break;
			case 2:
				glVertex3f(count, x, y, z);
				glVertex3f(count + 2, x, y, z);
				count++;
				break;
			case 3:
				glVertex3f(count, x, y, z);
				count += 3;
				break;
			}
			expand++;
			if (expand > 3) {
				expand = 0;
			}
			if (count >= maxCount) {
				if (isLimit(count, batchType)) {
					int type = batchType;
					glEnd();
					batchType = type;
				}
			}
		}
	}

	public final void glTexCoord2f(float fcol, float frow) {
		coord[0] = fcol;
		coord[1] = frow;
	}

	public void glColor4f(float r, float g, float b, float a) {
		color[0] = r;
		color[1] = g;
		color[2] = b;
		color[3] = a;
		isColor = true;
	}

	public void glColor4f(GLColor c) {
		glColor4f(c.r, c.g, c.b, c.a);
	}

	private boolean isLimit(int count, int type) {
		switch (type) {
		case GL.GL_TRIANGLES:
			return count % 3 == 0;
		case GL.GL_LINES:
			return count % 2 == 0;
		case GL.GL_QUADS:
			return count % 4 == 0;
		}
		return false;
	}

	public void lock() {
		this.isLocked = true;
	}

	public void unLock() {
		this.isLocked = false;
	}

	/**
	 * 开始批处理
	 * 
	 */
	public void glBegin() {
		glBegin(GL10.GL_TRIANGLES);
	}

	/**
	 * 以指定渲染形式开始批处理
	 * 
	 * @param type
	 */
	public void glBegin(int type) {
		this.batchType = type;
		this.useBegin = true;
		this.isColor = false;
		if (!isLocked) {
			this.expand = 0;
			this.count = 0;
		}
	}

	/**
	 * 构建顶点Buffer
	 * 
	 */
	private void make(int size) {
		if (vertexBuffer == null) {
			vertexBuffer = BufferUtils.createFloatBuffer(size * 3);
		}
		if (colorBuffer == null) {
			colorBuffer = BufferUtils.createFloatBuffer(size * 4);
		}
		if (coordBuffer == null) {
			coordBuffer = BufferUtils.createFloatBuffer(size * 2);
		}
		this.maxCount = size;
	}

	/**
	 * 注入顶点数据
	 * 
	 */
	private void insertVertices() {
		if (isLocked) {
			return;
		}
		oldVertCount = count * 3;
		vertexBuffer.limit(oldVertCount);
		vertexBuffer.put(verts, 0, oldVertCount);
		vertexBuffer.flip();
		if (isColor) {
			oldColorCount = count * 4;
			colorBuffer.limit(oldColorCount);
			colorBuffer.put(cols, 0, oldColorCount);
			colorBuffer.flip();
		}
		int size = count * 2;
		if (lockCoord && size == oldCoordCount) {
			return;
		}
		coordBuffer.limit(size);
		coordBuffer.put(coords, 0, size);
		coordBuffer.flip();
		oldCoordCount = size;
	}

	/**
	 * 提交顶点数据到渲染器
	 * 
	 */
	public void glEnd() {
		if (count == 0 || !useBegin) {
			this.useBegin = false;
			return;
		}
		this.insertVertices();
		GLEx.self.glDrawArrays(texture, vertexBuffer, coordBuffer, colorBuffer,
				isColor, count, moveX, moveY);
		this.useBegin = false;
	}

	/**
	 * 提交缓存中的数据
	 * 
	 */
	public void glCacheCommit() {
		if (count == 0) {
			return;
		}
		if (isLocked) {
			GLEx.self.glDrawArrays(texture, vertexBuffer, coordBuffer,
					colorBuffer, isColor, count, moveX, moveY);
		}
	}

	/**
	 * 提交缓存数据
	 * 
	 * @param tex2d
	 * @param cache
	 */
	public final static void commit(LTexture tex2d, GLCache cache) {
		if (cache.count == 0) {
			return;
		}
		GLEx.self.glDrawArrays(tex2d, cache);
	}

	public void draw(float x, float y, float width, float height) {
		draw(null, x, y, width, height, 0, 0, width, height);
	}

	public void draw(float x, float y, float width, float height, float srcX,
			float srcY, float srcWidth, float srcHeight) {
		draw(null, x, y, width, height, srcX, srcY, srcWidth, srcHeight);
	}

	public void draw(GLColor[] colors, float x, float y, float width,
			float height) {
		draw(colors, x, y, width, height, 0, 0, width, height);
	}

	public void draw(GLColor[] colors, float x, float y, float width,
			float height, float srcX, float srcY, float srcWidth,
			float srcHeight) {
		if (!useBegin) {
			return;
		}
		if (isLocked) {
			return;
		}
		float xOff = ((srcX / texWidth) * texture.widthRatio) + texture.xOff;
		float yOff = ((srcY / texHeight) * texture.heightRatio) + texture.yOff;
		float widthRatio = ((srcWidth / texWidth) * texture.widthRatio);
		float heightRatio = ((srcHeight / texHeight) * texture.heightRatio);

		if (colors == null) {
			glTexCoord2f(xOff, yOff);
			glVertex3f(x, y, 0);
			glTexCoord2f(xOff, heightRatio);
			glVertex3f(x, y + height, 0);
			glTexCoord2f(widthRatio, heightRatio);
			glVertex3f(x + width, y + height, 0);
			glTexCoord2f(widthRatio, yOff);
			glVertex3f(x + width, y, 0);
		} else {
			isColor = true;
			glColor4f(colors[LTexture.TOP_LEFT]);
			glTexCoord2f(xOff, yOff);
			glVertex3f(x, y, 0);
			glColor4f(colors[LTexture.BOTTOM_LEFT]);
			glTexCoord2f(xOff, heightRatio);
			glVertex3f(x, y + height, 0);
			glColor4f(colors[LTexture.BOTTOM_RIGHT]);
			glTexCoord2f(widthRatio, heightRatio);
			glVertex3f(x + width, y + height, 0);
			glColor4f(colors[LTexture.TOP_RIGHT]);
			glTexCoord2f(widthRatio, yOff);
			glVertex3f(x + width, y, 0);
		}
	}

	public LTexture getTexture() {
		return texture;
	}

	public int getHeight() {
		return texHeight;
	}

	public int getWidth() {
		return texWidth;
	}

	public float getX() {
		return moveX;
	}

	public void setX(float x) {
		this.moveX = x;
	}

	public float getY() {
		return moveY;
	}

	public void setY(float y) {
		this.moveY = y;
	}

	public void setLocation(float x, float y) {
		this.moveX = x;
		this.moveY = y;
	}

	public float[] getCols() {
		return cols;
	}

	public float[] getCoords() {
		return coords;
	}

	public float[] getVerts() {
		return verts;
	}

	public FloatBuffer getColorBuffer() {
		return colorBuffer;
	}

	public FloatBuffer getCoordBuffer() {
		return coordBuffer;
	}

	public FloatBuffer getVertexBuffer() {
		return vertexBuffer;
	}

	public int getOldColorCount() {
		return oldColorCount;
	}

	public int getOldCoordCount() {
		return oldCoordCount;
	}

	public int getOldVertCount() {
		return oldVertCount;
	}

	public boolean isLockCoord() {
		return lockCoord;
	}

	public void setLockCoord(boolean lockCoord) {
		this.lockCoord = lockCoord;
	}

	public void postLastCache() {
		if (lastCache != null) {
			LTextureBatch.commit(texture, lastCache);
		}
	}

	public GLCache getLastCache() {
		return lastCache;
	}

	public GLCache newGLCache(boolean reset) {
		return (lastCache = new GLCache(this, reset));
	}

	public GLCache newGLCache() {
		return newGLCache(false);
	}

	public void destroy() {
		if (texture != null) {
			texture.destroy();
		}
	}

	public void dispose() {
		this.count = 0;
		this.useBegin = false;
		this.isLocked = true;
		this.vertexBuffer = null;
		this.coordBuffer = null;
		this.colorBuffer = null;
		this.verts = null;
		this.cols = null;
		this.coords = null;
		if (lastCache != null) {
			lastCache.dispose();
			lastCache = null;
		}
	}

}
