package org.loon.framework.android.game.action.sprite;

import java.util.ArrayList;

import org.loon.framework.android.game.core.LObject;
import org.loon.framework.android.game.core.LSystem;
import org.loon.framework.android.game.core.geom.Ellipse;
import org.loon.framework.android.game.core.geom.RectBox;
import org.loon.framework.android.game.core.graphics.opengl.GL;
import org.loon.framework.android.game.core.graphics.opengl.GLEx;
import org.loon.framework.android.game.core.graphics.opengl.LTexture;
import org.loon.framework.android.game.core.input.LTouch;
import org.loon.framework.android.game.core.timer.LTimer;
import org.loon.framework.android.game.utils.MathUtils;

/**
 * Copyright 2008 - 2011
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * @project loonframework
 * @author chenpeng
 * @email：ceponline@yahoo.com.cn
 * @version 0.1
 */
/**
 * 0.3.3新增类，用以模拟一个抛物线
 */
public class Parabola extends LObject implements ISprite {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private float gravity;

	private float vx, vy;

	private boolean isBinding;

	private boolean isDirty;

	private Bind bind;

	private LTimer timer;

	private ArrayList<Ellipse> paths;

	private boolean save, visible, showPath;

	private int width, height;

	public Parabola(Object o) {
		this(o, LSystem.screenRect.width, LSystem.screenRect.height);
	}

	public Parabola(Object o, int w, int h) {
		if (o != null) {
			bind = new Bind(o);
			if (bind != null) {
				this.isBinding = true;
			}
		} else {
			this.isBinding = false;
		}
		this.gravity = 200f;
		this.width = w;
		this.height = h;
		this.visible = true;
		this.isDirty = false;
		this.showPath = true;
	}

	public float getDirection(LTouch e) {
		return getDirection(e.getX(), e.getY());
	}

	public float getDirection(float x, float y) {
		if (isBinding) {
			return MathUtils.atan2(y - bind.getY(), x - bind.getX());
		} else {
			return 0F;
		}
	}

	public void fire(float speed, LTouch e) {
		fire(speed, getDirection(e));
	}

	public void fire(float speed, float direction) {
		if (isBinding) {
			vx = speed * MathUtils.cos(direction);
			vy = speed * MathUtils.sin(direction);
			if (paths != null) {
				paths.clear();
			}
			isDirty = true;
		}
	}

	public void fire(float x, float y, float speed, LTouch e) {
		fire(x, y, speed, getDirection(e));
	}

	public void fire(float x, float y, float speed, float direction) {
		if (isBinding) {
			bind.callPos(x, y);
			vx = speed * MathUtils.cos(direction);
			vy = speed * MathUtils.sin(direction);
			if (paths != null) {
				paths.clear();
			}
			isDirty = true;
		}
	}

	public void fire(float tx, float ty, float dt) {
		if (isBinding) {
			float dx = tx - bind.getX();
			float dy = ty - bind.getY();
			vx = dx / dt;
			vy = 1f / dt * (dy - 1.0f / 2.0f * gravity * dt * dt);
			if (paths != null) {
				paths.clear();
			}
			isDirty = true;
		}
	}

	public void fire(float x, float y, float tx, float ty, float dt) {
		if (isBinding) {
			bind.callPos(x, y);
			float dx = tx - x;
			float dy = ty - y;
			vx = dx / dt;
			vy = 1f / dt * (dy - 1.0f / 2.0f * gravity * dt * dt);
			if (paths != null) {
				paths.clear();
			}
			isDirty = true;
		}
	}

	public int getWidth() {
		if (isBinding) {
			return bind.getWidth();
		}
		return 0;
	}

	public int getHeight() {
		if (isBinding) {
			return bind.getHeight();
		}
		return 0;
	}

	public void update(long elapsedTime) {
		if (isBinding) {
			if (!isDirty) {
				return;
			}
			float x = bind.getX();
			float y = bind.getY();
			float dt = MathUtils.max((elapsedTime / 1000), 0.01f);
			vy += gravity * dt;
			x += vx * dt;
			y += vy * dt;
			bind.callPos(x, y);
			if (x >= width || y >= height) {
				isDirty = false;
			}
			bind.callUpdate(elapsedTime);

			if (save) {
				if (timer.action(elapsedTime)) {
					paths.add(new Ellipse(bind.getX(), bind.getY(), 20, 20));
				}
			}
		}
	}

	public void noSave() {
		this.save = false;
		if (paths != null) {
			paths.clear();
			paths = null;
		}
	}

	public void savePath(long delay) {
		if (timer == null) {
			timer = new LTimer(delay);
		} else {
			timer.setDelay(delay);
		}
		if (paths == null) {
			paths = new ArrayList<Ellipse>(10);
		}
		this.save = true;
	}

	public void savePath() {
		savePath(150);
	}

	public void createUI(GLEx g) {
		if (!visible) {
			return;
		}
		if (!isDirty) {
			if (save && showPath) {
				g.glBegin(GL.GL_LINE_STRIP);
				for (Ellipse e : paths) {
					float[] points = e.getPoints();
					for (int i = 0; i < points.length; i += 2) {
						g.glVertex2f(points[i], points[i + 1]);
					}
					if (e.closed()) {
						g.glVertex2f(points[0], points[1]);
					}
				}
				g.glEnd();
			}
			return;
		}
	}

	public float getAlpha() {
		return 0;
	}

	public LTexture getBitmap() {
		return null;
	}

	public RectBox getCollisionBox() {
		if (isBinding) {
			return getRect(bind.getX(), bind.getY(), bind.getWidth(), bind
					.getHeight());
		}
		return null;
	}

	public boolean isVisible() {
		return visible;
	}

	public void setVisible(boolean v) {
		this.visible = v;
	}

	public Bind getBind() {
		return bind;
	}

	public boolean isBinding() {
		return isBinding;
	}

	public boolean isDirty() {
		return isDirty;
	}

	public void setDirty(boolean isDirty) {
		this.isDirty = isDirty;
	}

	public float getGravity() {
		return gravity;
	}

	public void setGravity(float gravity) {
		this.gravity = gravity;
	}

	public ArrayList<Ellipse> getPaths() {
		return new ArrayList<Ellipse>(paths);
	}

	public boolean isShowPath() {
		return showPath;
	}

	public void setShowPath(boolean showPath) {
		this.showPath = showPath;
	}

	public void dispose() {
		this.visible = false;
		this.save = false;
		this.showPath = false;
		if (paths != null) {
			paths.clear();
			paths = null;
		}
		if (bind != null) {
			bind = null;
		}
	}

}
