package org.loon.framework.javase.game.action.map;

import org.loon.framework.javase.game.core.LRelease;
import org.loon.framework.javase.game.core.graphics.opengl.GLEx;
import org.loon.framework.javase.game.core.graphics.opengl.LTexture;
import org.loon.framework.javase.game.core.graphics.opengl.LTextureBatch;

/**
 * Copyright 2008 - 2011
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 * 
 * @project loonframework
 * @author chenpeng
 * @email：ceponline@yahoo.com.cn
 * @version 0.1
 */
public class TileMapBox implements LRelease {

	private LTextureBatch batch;

	private int tileWidth, tileHeight;

	private int width, height, showWidth, showHeight;

	public TileMapBox(String path, int tw, int th) {
		this(new LTexture(path), tw, th);
	}

	public TileMapBox(LTexture tex2d, int tw, int th) {
		this.batch = new LTextureBatch(tex2d);
		this.tileWidth = tw;
		this.tileHeight = th;
		this.width = tex2d.getWidth() / 2;
		this.height = tex2d.getHeight() / 2;
		this.showWidth = tileWidth;
		this.showHeight = tileHeight;
	}

	public void setTileSize(int w, int h) {
		this.showWidth = w;
		this.showHeight = h;
	}

	public void setImagePosTo(int tx, int ty, float x, float y) {
		setImagePosTo(tx, ty, x, y, showWidth, showHeight);
	}

	public void setImagePosTo(int tx, int ty, float x, float y, float w, float h) {
		batch.draw(x, y, w, h, tx * tileWidth, ty * tileHeight,
				(tx * tileWidth) + tileWidth, (ty * tileHeight) + tileHeight);
	}

	public void draw(GLEx g, float x, float y) {
		batch.create(g, x, y);
	}

	public void draw(GLEx g) {
		batch.create(g);
	}

	public int getHeight() {
		return height;
	}

	public int getWidth() {
		return width;
	}

	public LTextureBatch getBatch() {
		return batch;
	}

	public void dispose() {
		if (batch != null) {
			batch.dispose();
		}
	}

}
